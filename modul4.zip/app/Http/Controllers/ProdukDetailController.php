<?php

namespace App\Http\Controllers;

use App\ProdukDetail;
use Illuminate\Http\Request;

class ProdukDetailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ProdukDetail  $produkDetail
     * @return \Illuminate\Http\Response
     */
    public function show(ProdukDetail $produkDetail)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ProdukDetail  $produkDetail
     * @return \Illuminate\Http\Response
     */
    public function edit(ProdukDetail $produkDetail)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ProdukDetail  $produkDetail
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProdukDetail $produkDetail)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ProdukDetail  $produkDetail
     * @return \Illuminate\Http\Response
     */
    public function destroy(ProdukDetail $produkDetail)
    {
        //
    }
}
