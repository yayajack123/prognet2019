<?php

namespace App\Http\Controllers;

use App\Transaction_det;
use Illuminate\Http\Request;

class TransactionDetController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Transaction_det  $transaction_det
     * @return \Illuminate\Http\Response
     */
    public function show(Transaction_det $transaction_det)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Transaction_det  $transaction_det
     * @return \Illuminate\Http\Response
     */
    public function edit(Transaction_det $transaction_det)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Transaction_det  $transaction_det
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Transaction_det $transaction_det)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Transaction_det  $transaction_det
     * @return \Illuminate\Http\Response
     */
    public function destroy(Transaction_det $transaction_det)
    {
        //
    }
}
