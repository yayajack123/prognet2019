<?php $__env->startSection('title','Your Cart'); ?>
<?php $__env->startSection('page',' Cart'); ?>
<?php $__env->startSection('content'); ?>

<!-- catg header banner section -->
<section id="aa-catg-head-banner">
    <img src="img/fashion/fashion-header-bg-8.jpg" alt="fashion img">
    <div class="aa-catg-head-banner-area">
      <div class="container">
       <div class="aa-catg-head-banner-content">
         <h2>Cart Page</h2>
         <ol class="breadcrumb">
           <li><a href="index.html">Home</a></li>                   
           <li class="active">Cart</li>
         </ol>
       </div>
      </div>
    </div>
   </section> 
   <!-- / catg header banner section -->
 
  <!-- Cart view section -->
  <section id="cart-view">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="cart-view-area">
            <div class="cart-view-table">
                <div class="table-responsive">
                   <table class="table">
                     <thead>
                       <tr>
                         <th></th>
                         <th></th>
                         <th>Product</th>
                         <th>Price</th>
                         <th>Quantity</th>
                         <th>Total</th>
                       </tr>
                     </thead>
                     <tbody>
                            <?php $__currentLoopData = $cart_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                    $image_products=DB::table('products')->select('image_name')->join('product_images','product_images.product_id','=','products.id')->where('products.id',$cart_data->product_id)->get();
                                    $image_data = DB::table('products')->where('products.id',$cart_data->product_id)->get()->first();
                            ?>
                            <input type="hidden" name="stock" id="stock-<?php echo e($cart_data->product_id); ?>" value="<?php echo e($cart_data->stock); ?>">
                       <tr id="tr-<?php echo e($cart_data->product_id); ?>">
                          <script type="text/javascript">
                            $(document).ready(function(){
                                $('#klik-<?php echo e($cart_data->product_id); ?>').click(function(){
                                    var qty_awal = $('.cart_quantity_input-<?php echo e($cart_data->product_id); ?>').val();
                                    var stock = parseInt($('#stock-<?php echo e($cart_data->product_id); ?>').val());
                                    var qty_akhir = parseInt(qty_awal) + 1;
                                    if (qty_akhir > stock) {
                                        alert("stok tidak mencukupi!");
                                    }
                                    else{
                                        $('.cart_quantity_input-<?php echo e($cart_data->product_id); ?>').val(qty_akhir);    
                                    }
                                    event.preventDefault();
                                });

                                $('#klik1-<?php echo e($cart_data->product_id); ?>').click(function(){
                                    var qty_awal = $('.cart_quantity_input-<?php echo e($cart_data->product_id); ?>').val();
                                    var qty_akhir = parseInt(qty_awal) - 1;
                                    if (qty_akhir == 0) {
                                        var qty_akhir = 1;
                                    }
                                    $('.cart_quantity_input-<?php echo e($cart_data->product_id); ?>').val(qty_akhir);
                                    event.preventDefault();
                                });

                                $('#hapus-<?php echo e($cart_data->product_id); ?>').click(function(){
                                    console.log("terklik");
                                    $('#tr-<?php echo e($cart_data->product_id); ?>').remove();
                                });

                            });
                        </script>
                         <td><a class="cart_quantity_delete" href="javascript:" rel="<?php echo e($cart_data->id); ?>"  id="hapus-<?php echo e($cart_data->id); ?>"><fa class="fa fa-close"></fa></a></td>
                         <?php $__currentLoopData = $image_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <td><a href="#"><img src="<?php echo e(url('images/',$images_product->image_name)); ?>" alt="img"></a></td>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       <td><a class="aa-cart-title" href="#"><?php echo e($image_data->product_name); ?></a></td>
                       <td>$<?php echo e($image_data->price); ?></td>
                         <td>
                           <input class="form-control" style="width:20%;" type="number" value="<?php echo e($cart_data->qty); ?>"></td>
                         <td><?php echo e($image_data->price*$cart_data->qty); ?></td>
                       </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </tbody>
                   </table>
                 </div>
        
              <!-- Cart Total view -->
              <div class="cart-view-total">
                <h4>Cart Totals</h4>
                <table class="aa-totals-table">
                  <tbody>
                    <tr>
                      <th>Total</th>
                      <td><?php echo e($total_price); ?></td>
                    </tr>
                  </tbody>
                  
                </table>
                <a href="<?php echo e(url('/check-out')); ?>" class="aa-cart-view-btn">Proced to Checkout</a>
              </div>
              
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
  <script>
      $(".cart_quantity_delete").click(function () {
          var id=$(this).attr('rel');
          var deleteFunction=$(this).attr('rel1');
          swal({
              title:'Are you sure?',
              text:"You won't be able to revert this!",
              type:'warning',
              showCancelButton:true,
              confirmButtonColor:'#3085d6',
              cancelButtonColor:'#d33',
              confirmButtonText:'Yes, delete it!',
              cancelButtonText:'No, cancel!',
              confirmButtonClass:'btn btn-success',
              cancelButtonClass:'btn btn-danger',
              buttonsStyling:false,
              reverseButtons:true
          },function () {
              window.location.href="/cart/deleteItem/"+id;
          });
      });
  
  </script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\PRAKTIKUM PROGNET\test_auth\resources\views/user/cart.blade.php ENDPATH**/ ?>