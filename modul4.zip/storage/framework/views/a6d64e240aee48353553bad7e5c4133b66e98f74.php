<?php $__env->startSection('title','Your Cart'); ?>
<?php $__env->startSection('page',' Cart'); ?>
<?php $__env->startSection('content'); ?>
<style type="text/css">
    legend,label,p{
        color: black;
    }
</style>
<div class="container">
    <div class="row">
        <div class="col-sm-4">
        <form action="/transaction/<?php echo e($data[0]->transaction_id); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field("PUT"); ?>
            <legend>Proof of Payment</legend>    
            <input type="hidden" name="id" id="id" value="<?php echo e($data[0]->transaction_id); ?>">
            <?php if(empty($data[0]->status)): ?>
                <div class="form-group">
                    <input type="file" name="proof_of_payment" id="proof_of_payment" class="form-control">>
                </div>

                <div style="text-align: left;">
                    <button type="submit" name="submit" class="btn btn-danger">Submit</button>
                </div>
            <?php elseif($data[0]->status == 'unverified'): ?>
            <div class="form-group">
                    <input type="file" name="proof_of_payment" id="proof_of_payment" class="form-control">>
                </div>

                <div style="text-align: left;">
                    <button type="submit" name="submit" class="btn btn-danger">Submit</button>
                </div>
            <?php elseif($data[0]->status == 'delivered'): ?>
                

                <div style="text-align: left;">
                    <button type="submit" name="submit"  id="success" class="btn btn-danger">Set Status Success</button>
                </div>
            <?php elseif($data[0]->status == 'success'): ?>
                </form>
                <p style="color: black;">Your Payment has Success</p>
                 <div style="text-align: left;">
                    <button type="submit" name="submit" onclick="myFunction()" id="ulasan" class="btn btn-danger">Review Item</button>
                </div>
            <?php else: ?>
                <p style="color: black;">Your Payment has Success</p>
            <?php endif; ?>
        </form>
        </div>
    </div>
</div>

<div class="container" id="review" style="display: none;">
<hr>
<br><br>
    <div class="row">
        <div class="col-sm-4">
        <form action="/review" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            
            <legend>Review Item</legend>    

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $image_products=DB::table('products')->select('image_name')->join('product_images','product_images.product_id','=','products.id')->where('products.id',$d->product_id)->get()->first();
            ?>
                <input type="hidden" name="product_id[]" value="<?php echo e($d->product_id); ?>">
                <table>
                <td><a href=""><img src="<?php echo e(url('images/small',$image_products->image_name)); ?>" alt="" style="width: 100px;"></a></td>
                <td>    </td>
                <td><p style="font-size: 30px; float: right;"><?php echo e($d->product_name); ?></p></td>
                </table>
                <br>
                <div class="form-group">
                    <label>Rating (1-5)</label>
                    <input autofocus="" type="text" name="rating[]"  class="form-control">>
                </div>
                <div class="form-group">
                    <label>Review</label>
                    <input type="text" name="review[]" class="form-control">>
                </div>
                
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <input type="submit" value="submit review" class="btn btn-danger">
        </form>
        </div>
    </div>
    <hr>
</div>

<br><br><br>
<div class="container">
<div class="row">
        <div class="col-sm-4">
            <legend>Detail Transaction</legend>
        </div>
    </div>
</div> 
<section id="cart_items">

    <div class="container">
        <?php if(Session::has('message')): ?>
            <div class="alert alert-success text-center" role="alert">
                <?php echo e(Session::get('message')); ?>

            </div>
        <?php endif; ?>
        <div class="table-responsive cart_info">
            <table class="table table-condensed">
                <thead>
                <tr class="cart_menu">
                    <td>No</td>
                    <td class="image">Item</td>
                    <td class="description">Name</td>
                    <td class="price">Price</td>
                    <td class="quantity">Quantity</td>
                    <td class="discount">Discount</td>
                    <td class="total">Total</td>
                    <td></td>
                </tr>
                </thead>
                <tbody style="color: black;">

                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                            $image_products=DB::table('products')->select('image_name')->join('product_images','product_images.product_id','=','products.id')->where('products.id',$data->product_id)->get()->first();
                            $image_data = DB::table('products')->where('products.id',$data->product_id)->get()->first();
                    ?>
                    
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td class="cart_product">
                                
                                    <a href=""><img src="<?php echo e(url('images',$image_products->image_name)); ?>" alt="" style="width: 100px;"></a>
                                
                            </td>
                            <td class="cart_description">
                                <p style="font-size: 15px"><?php echo e($image_data->product_name); ?></p>
                            </td>
                            <td class="cart_price">
                                <p style="font-size: 15px">Rp <?php echo e(number_format($image_data->price)); ?></p>
                            </td>

                            <td class="cart_quantity">
                                <?php echo e($data->qty); ?>

                            </td>
                            <td>
                                <?php echo e($data->discount); ?>%
                            </td>

                            <td class="cart_total">
                                <p style="font-size: 15px">Rp <?php echo e(number_format($data->qty*$data->selling_price)); ?></p>
                            </td>
                            
                        </tr>

                        
                         
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    

</section> <!--/#cart_items-->

<section id="do_action">
    <div class="container">
        
        <div class="row">
            <div class="col-sm-6">
            
            </div>
            <div class="col-sm-6">
                <?php if(Session::has('message_apply_sucess')): ?>
                    <div class="alert alert-success text-center" role="alert">
                        <?php echo e(Session::get('message_apply_sucess')); ?>

                    </div>
                <?php endif; ?>
                <div class="total_area" >
                    <ul>
                            <li style="background: white; color: black;">Shipping Cost <span>Rp <?php echo e(number_format($data->shipping_cost)); ?></span></li>         
                            <li style="background: white; color: black;">Sub Total <span>Rp <?php echo e(number_format($total_price)); ?></span></li>
                            <li >Total <span>Rp <?php echo e(number_format($data->shipping_cost+$total_price)); ?></span></li>
                    </ul>
                    
                    
                </div>
            </div>
        </div>
    </div>
</section><!--/#do_action-->
<script type="text/javascript">
    //  $(document).ready(function(){
    //     $.ajaxSetup({
    //         headers: {
    //             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    //         }
    //     });

    //     $('#success').click(function(){
    //         console.log("terklik");
    //         var baseUrl = window.location.protocol+"//"+window.location.host;
    //         var status = "success"
    //         var id = parseInt($('#id').val());
    //         console.log(id);
            
    //         $.ajax({
    //               url: baseUrl+'/transactionStatus/'+id,  
    //               type : 'post',
    //               dataType: 'JSON',
    //               data: {
    //                 "_token": "<?php echo e(csrf_token()); ?>",
    //                 id: id,
                    
    //                 },
    //               success:function(response){
                        
    //                     event.preventDefault();
    //               },
    //               error:function(){
    //                 alert("fail");
    //               }

    //           });
    //     });
    // });

    function myFunction() {
    
    var x = document.getElementById("review");
    
      if (x.style.display === "none") {
        x.style.display = "block";

      } 
      else {
        x.style.display = "none";
      }
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\PRAKTIKUM PROGNET\test_auth\resources\views//user/transaction_detail.blade.php ENDPATH**/ ?>