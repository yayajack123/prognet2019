<?php /* D:\KULIAH\PRAKTIKUM PROGNET\test_auth\resources\views//admin/transaksi/approvement.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php if(Session::has('message')): ?>
        <div class="alert alert-success text-center" role="alert">
            <strong>Well done!</strong> <?php echo e(Session::get('message')); ?>

        </div>
    <?php endif; ?>
    <div class="widget-box">
        <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <h5>Approvement</h5>
        </div>
        <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
                <thead>
                <tr>
                    <th>No</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Total</th>
                    <th>Corier</th>
                    <th>Timeout</th>
                    <th>Detail</th>
                    <th>Status</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($index->name); ?></td>
                    <td><?php echo e($index->address); ?></td>
                    <td>Rp <?php echo e(number_format($index->total)); ?></td>
                    <td><?php echo e($index->courier); ?></td>
                    <td><?php echo e($index->timeout); ?></td>
                    <td>
                        <center><a href="/admin/transactionAdmin/<?php echo e($index->id); ?>"><button class="btn-success">Detail & Verify</button></a></center>
                    </td>
                    <td><?php echo e($index->status); ?></td>
                    
                </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsblock'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="<?php echo e(asset('js/jquery.ui.custom.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.uniform.js')); ?>"></script>
<script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/matrix.js')); ?>"></script>
<script src="<?php echo e(asset('js/matrix.tables.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
<script>
  $(document).on('click', '.deleteRecord', function (e) {
      e.preventDefault();
      var id = $(this).data('id');
      swal({
        title: "Are you sure!",
        type: "error",
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Yes!",
        showCancelButton: true,
       },
       function () {
          $.ajax({
            type: "POST",
            url: "admin/courier/"+id,
            data: {id:id},
            success: function (data) {
                          //
                }         
        });
       });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>