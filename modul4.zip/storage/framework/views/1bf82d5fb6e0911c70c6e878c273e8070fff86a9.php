<?php $__env->startSection('title','Your Cart'); ?>
<?php $__env->startSection('page',' Cart'); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <?php if(Session::has('message')): ?>
        <div class="alert alert-success text-center" role="alert">
            <?php echo e(Session::get('message')); ?>

        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-sm-1"></div>
        <div class="col-sm-4">
        <form action="/check-shipping" method="get" class="form-horizontal">
            
                <div class="login-form"><!--login form-->
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                    <legend>Pengiriman</legend>

                    
                    <div class="form-group <?php echo e($errors->has('billing_name')?'has-error':''); ?>">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" name="nama" id="name" value="<?php echo e($user_login->name); ?>">
                        <span class="text-danger"><?php echo e($errors->first('nama')); ?></span>
                    </div>

                    <div class="form-group">
                        <label for="name">City</label>
                        <select name="kota" id="billing_city" >
                            <option>Pilih Kota Tujuan</option>
                            <?php for($i = 0; $i < count($countries); $i++ ): ?>
                                <option value="<?php echo e($countries[$i]["postal_code"]); ?>"><?php echo e($countries[$i]["city_name"].', '.$countries[$i]["province"]); ?></option>

                                
                                
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="name">Postal Code</label>
                        <input type="text" id="postal" name="postal" disabled="" class="form-control" >
                    </div>

                     <div class="form-group">
                        <label for="name">Courier</label>
                        <select name="kurir" id="kurir" class="select2-container">
                            <option>Pilih Kurir</option>
                            <?php $__currentLoopData = $courier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($courier->courier); ?>"><?php echo e($courier->courier); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="name">Address</label>
                        <input type="text" class="form-control" value="<?php echo e($user_login->address); ?>" name="alamat" id="billing_address" placeholder="Address">
                        <span class="text-danger"><?php echo e($errors->first('billing_address')); ?></span>
                    </div>
                    
                    <div class="form-group <?php echo e($errors->has('billing_mobile')?'has-error':''); ?>">
                        <label for="name">Phone</label>
                        <input type="text" class="form-control" name="telpon" id="billing_mobile" placeholder="phone">
                        <span class="text-danger"><?php echo e($errors->first('billing_mobile')); ?></span>
                    </div>

                    <div class="form-group">
                        <label>Total Cart</label>
                        <input type="text" class="form-control" name="total_price" disabled="" value="Rp <?php echo e(number_format($total_price)); ?>">

                    </div>

                    
                    <div style="text-align: center;">
                    <button type="submit" name="submit" class="btn btn-primary">Cek Ongkir</button>
                    </div>
                </div><!--/login form-->
            
        </form>
    </div>
        <div class="col-sm-1">

        </div>
        <?php if(isset($service)): ?>
        <div class="col-sm-4">
            <form action="/order-review" method="get" class="form-horizontal">
                <div class="signup-form"><!--login form-->
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                    <legend>Harga</legend>

                    <input type="hidden" id="total_price" name="total_price" value="<?php echo e($total_price); ?>">
                    <input type="hidden" name="provinsi" value="<?php echo e($provinsi); ?>">
                    <input type="hidden" name="kurir" value="<?php echo e($kurir); ?>">
                    <input type="hidden" value="<?php echo e($kota); ?>" name="kota">
                    <input type="hidden" name="alamat" value="<?php echo e($alamat); ?>">
                    <input type="hidden" name="nama" value="<?php echo e($nama); ?>">
                    <input type="hidden" name="telpon" value="<?php echo e($telpon); ?>">
                    <div class="form-group">
                        <label for="name">Kurir</label>
                        <input type="text" disabled="" name="kurir" class="form-control" value="<?php echo e($kurir); ?>">
                    </div>

                    <div class="form-group">
                        <label for="name">Service</label>
                        <select name="service" class="select2-container" id="service">
                            <option>Pilih Service</option>
                            <?php for($i = 0; $i < count($service); $i++ ): ?>
                                <option value="<?php echo e($service[$i]["cost"]["0"]["value"]); ?>"><?php echo e($service[$i]["service"].', estimasi('.$service[$i]["cost"]["0"]["etd"].' hari)'); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Ongkos Kirim</label>
                        <input type="text" name="ongkir" id="ongkir" disabled="" class="form-control">
                    </div>

                    <div class="form-group">
                        <label>Total</label>
                        <input type="text" name="total" id="total" disabled="" class="form-control">
                    </div>

                    <div style="text-align: center;">
                        <button type="submit" name="submit" class="btn btn-primary">Review Order</button>
                    </div>

                </div><!--/login form-->
            
        </form>
        </div>
        <?php endif; ?>
        <div class="col-sm-1"></div>
    </div>
</div>
<div style="margin-bottom: 20px;"></div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script>
     $(document).ready(function(){

        $('#billing_city').click(function(){                            
             var city = $('#billing_city').val();
             console.log(city)
             $('#postal').val(city);
             event.preventDefault();
        });

        $('#service').click(function(){
             var total = $('#total_price').val();                            
             var ongkir = $('#service').val();

             var totall = parseInt(total) + parseInt(ongkir);
             console.log(ongkir)
             $('#ongkir').val(ongkir);
             $('#total').val(totall);
             event.preventDefault();
        });



    });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\PRAKTIKUM PROGNET\test_auth\resources\views/checkout/index.blade.php ENDPATH**/ ?>