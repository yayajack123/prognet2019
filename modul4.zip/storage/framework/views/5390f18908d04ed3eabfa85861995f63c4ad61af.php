<?php /* D:\KULIAH\PRAKTIKUM PROGNET\test_auth\resources\views//admin/produk/edit.blade.php */ ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Edit Produk</div>
                    <div class="card-body">

                            <form action="/admin/produk/<?php echo e($test->id); ?>" method="POST" >
                                <?php echo e(csrf_field()); ?>

                                <?php echo method_field("PUT"); ?>
                                <input type="text" name="nama_produk" value="<?php echo e($test->product_name); ?>" required="" class="form-control"><br>
                                <input type="number" name="harga" value="<?php echo e($test->price); ?>" required="" class="form-control"><br>
                                <input type="text" name="deskripsi" value="<?php echo e($test->description); ?>" required="" class="form-control"><br>
                                <input type="number" name="rating" value="<?php echo e($test->product_rate); ?>" required=""class="form-control"><br>
                                <input type="number" name="stok" value="<?php echo e($test->stock); ?>" required=""class="form-control"><br>
                                <input type="number" name="berat" value="<?php echo e($test->weight); ?>" required="" class="form-control"><br>
                                <input type="submit" name="submit" value="update">
                            </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>