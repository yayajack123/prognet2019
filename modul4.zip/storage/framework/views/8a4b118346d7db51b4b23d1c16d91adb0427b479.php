<?php /* D:\KULIAH\PRAKTIKUM PROGNET\test_auth\resources\views/admin/kurir/kurir.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
                 <div class="card">
                    <div class="card-header">Tambah Kurir</div>
                    <div class="card-body">
                            <form action="/admin/kurir" method="POST">
                                <?php echo csrf_field(); ?>
                                <input class="form-control" type="text" name="nama_kurir" placeholder="nama kurir" required><br>
                                <input type="submit" value="submit" class="btn btn-primary">
                            </form>
                    </div>                
                </div>
                <br>
                <div class="card">
                        <div class="card-header">List kurir</div>
                        <div class="card-body">
                                <div class="table-responsive">
                                        <table class="table table-striped ">
                                            <thead>
                                                <tr>
                                                    <th>No.</th>
                                                    <th>List kurir</th>
                                                    <th>Edit</th>
                                                    <th>Delete</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td> <?php echo e($m->courier); ?></td>
                                                        <td>
                                                            <form action="admin/kurir/<?php echo e($m->id); ?>/edit" method="GET">
                                                                <?php echo csrf_field(); ?>
                                                                <button type="submit" class="btn btn-warning">
                                                                    Edit
                                                                </button>
                                                            </form>
                                                        </td>
                                                        <td>
                                                            <form action="/admin/kurir/<?php echo e($m->id); ?>/" method="POST">
                                                                <?php echo method_field("DELETE"); ?>
                                                                <?php echo csrf_field(); ?>
                                                                <button type="submit" class="btn btn-danger">
                                                                    DELETE
                                                                </button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                        </div>                
                    </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>