<?php /* D:\KULIAH\PRAKTIKUM PROGNET\test_auth\resources\views/admin/produk/index.blade.php */ ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">List Product</div>
                    <div class="card-body">
                            <a href="/admin/produk/create">Tambah Produk</a>
                            <table class="table table-hover">
                                <thead>
                                    <th>No</th>
                                    <th>Nama Produk</th>
                                    <th>Harga</th>
                                    <th>Deskripsi</th>
                                    <th>Rating</th>
                                    <th>Stok</th>
                                    <th>Berat</th>
                                    <th>Foto</th>
                                    <th>Aksi</th>
                                    
                                </thead>
                                <tbody>
                                    
                                    <?php $__currentLoopData = $index; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($index['product_name']); ?></td>
                                        <td><?php echo e($index['price']); ?></td>
                                        <td><?php echo e($index['description']); ?></td>
                                        <td><?php echo e($index['product_rate']); ?></td>
                                        <td><?php echo e($index['stock']); ?></td>
                                        <td><?php echo e($index['weight']); ?></td>
                                    
                                        <td><img src="<?php echo e(asset('images/'.$index['image_name'])); ?>" height="50" width="50" alt="img"></td>
                                        <td><form action="/admin/produk/<?php echo e($index->id); ?>/edit" method="GET">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-warning"><i class="glyphicon glyphicon-edit"></i>Edit</button>
                                            </form>
                                        </form>
                                        <form style="float: right;" action="/admin/produk/<?php echo e($index->id); ?>/" method="POST">
                                        <?php echo method_field("DELETE"); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger">Delete<i class="fa fa-trash-o fa-fw" onclick="return confirm('Yakin ingin menghapus data?')"></i>
                                        </button>
                                    </form>
                        
                                        </td> 
                                    </tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsblock'); ?>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
    <script>
        $(".deleteRecord").click(function () {
            var id=$(this).attr('rel');
            var deleteFunction=$(this).attr('rel1');
            swal({
                title:'Are you sure?',
                text:"You won't be able to revert this!",
                type:'warning',
                showCancelButton:true,
                confirmButtonColor:'#3085d6',
                cancelButtonColor:'#d33',
                confirmButtonText:'Yes, delete it!',
                cancelButtonText:'No, cancel!',
                confirmButtonClass:'btn btn-success',
                cancelButtonClass:'btn btn-danger',
                buttonsStyling:false,
                reverseButtons:true
            },function () {
                window.location.href="/admin/"+deleteFunction+"/"+id;
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>