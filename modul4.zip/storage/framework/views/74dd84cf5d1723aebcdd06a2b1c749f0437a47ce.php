<?php /* D:\KULIAH\PRAKTIKUM PROGNET\test_auth\resources\views//admin/produk/create.blade.php */ ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Tambah Produk</div>
                    <div class="card-body">
                            <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger">
                                    <strong>Whoops!</strong> There were some problems with your input.<br><br>
                                    <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <?php endif; ?>

                                    <?php if(session('success')): ?>
                                    <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                    </div> 
                                    <?php endif; ?>


                            <form action="/admin/produk" enctype="multipart/form-data" method="POST">
                                <?php echo csrf_field(); ?>
                                Nama :
                                <input type="text" name="nama_produk" required="" class="form-control"><br>
                                Harga : 
                                <input type="number" name="harga" required="" class="form-control"><br>
                                Rating : 
                                <input type="number" name="rating" required="" class="form-control"><br>
                                Stok : 
                                <input type="number" name="stok" required="" class="form-control"><br>
                                Berat : 
                                <input type="number" name="berat" required="" class="form-control"><br>
                                kategori : 
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="checkbox" name="kategori[]" value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?>  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <br><br>
                                Foto:
                                <div class="input-group control-group increment" >
                                    <input type="file" name="filename[]" class="form-control" multiple="multiple">
                                
                                </div>
                        
                        <br>
                        Deskripsi : <input type="text" name="deskripsi" required="" class="form-control"><br>

                        <button type="submit" class="btn btn-primary" style="margin-top:10px">Submit</button>
                            </form>
                            
                    </div>                
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>