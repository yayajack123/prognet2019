<?php $__env->startSection('title','Your Cart'); ?>
<?php $__env->startSection('page',' Cart'); ?>
<?php $__env->startSection('content'); ?>

    <style type="text/css">
        #shipping{
            color: black;
        }
    </style>
    <div class="container">
        <div class="step-one">
            <h2 class="heading">Shipping To</h2>
        </div>
        <div class="row">
            <form action="<?php echo e(url('/cod')); ?>" method="post" class="form-horizontal">
                <?php echo csrf_field(); ?>
                <div class="col-sm-12">
                    <div class="table-responsive" id="shipping">
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Alamat</th>
                                <th>Kota</th>
                                <th>Provinsi</th>
                                <th>Telpon</th>
                                <th>Ongkos Kirim</th>
                                <th>Sub Harga</th>
                                <th>Harga Total</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td><?php echo e($data['nama']); ?></td>
                                <td><?php echo e($data['alamat']); ?></td>
                                <td><?php echo e($data['kota']); ?></td>
                                <td><?php echo e($data['provinsi']); ?></td>
                                <td><?php echo e($data['telpon']); ?></td>
                                <td><?php echo e($data['service']); ?></td>
                                <td>Rp <?php echo e(number_format($data['total_price'])); ?></td>
                                <td>Rp <?php echo e(number_format($total)); ?></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <section id="cart_items">
                        <div class="review-payment">
                            <h2>Review & Payment</h2>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                <tr class="cart_menu">
                                    <td class="image">Item</td>
                                    <td class="description"></td>
                                    <td class="price">Price</td>
                                    <td class="quantity">Quantity</td>
                                    <td>Discount</td>
                                    <td class="total">Total</td>
                                </tr>
                                </thead>
                                <tbody style="color: black;">
                                <?php $__currentLoopData = $cart_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <?php
                                    $image_products=DB::table('products')->select('image_name')->join('product_images','product_images.product_id','=','products.id')->where('products.id',$cart_data->product_id)->get()->first();
                                    $image_data = DB::table('products')->where('products.id',$cart_data->product_id)->get()->first();
                                ?>
                                    <tr>
                                    <td class="cart_product">
                                        <a href=""><img src="<?php echo e(url('images/small',$image_products->image_name)); ?>" alt="" style="width: 100px;"></a>
                                    </td>
                                    <td class="cart_description">
                                        <h4><a href=""><?php echo e($image_data->product_name); ?></a></h4>
                                    </td>
                                    <td class="cart_price">
                                        <p>Rp. <?php echo e($image_data->price); ?></p>
                                    </td>
                                    <td class="cart_quantity">
                                        <p><?php echo e($cart_data->qty); ?></p>
                                    </td>
                                    <td>
                                        <p><?php echo e($cart_data->percentage); ?>%</p>
                                    </td>
                                    <td class="cart_total">
                                        <p class="cart_total_price">Rp. <?php echo e($cart_data->price*$cart_data->qty); ?></p>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="4">&nbsp;</td>
                                    <td colspan="2">
                                        <table class="table table-condensed total-result">
                                            <tr>
                                                <td>Cart Sub Total</td>
                                                <td>Rp. <?php echo e($data['total_price']); ?></td>
                                            </tr>
                                            
                                            <tr>
                                                <td>Total</td>
                                                <td><span>Rp. <?php echo e($data['total_price']); ?></span></td>
                                            </tr>
                                            
                                        </table>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="payment-options">
                            <button type="submit" class="btn btn-primary" style="float: right;">Order Now</button>
                        </div>
                    </section>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" name="data[]" value="<?php echo e($data); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </form>
        </div>
    </div>
    <div style="margin-bottom: 20px;"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\PRAKTIKUM PROGNET\test_auth\resources\views/checkout/review_order.blade.php ENDPATH**/ ?>