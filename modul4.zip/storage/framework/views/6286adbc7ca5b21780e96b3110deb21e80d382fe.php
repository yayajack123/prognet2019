<?php $__env->startSection('content'); ?>
    
    <div class="container-fluid">
        <div class="row-fluid">
            
            
            <div class="span12">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-info-sign"></i> </span>
                    <h5>Proof of Payment</h5>
                </div>
                <div class="widget-content nopadding">
                    <form class="form-horizontal" method="post" action="/admin/transactionAdmin/<?php echo e($data[0]->transaction_id); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                        <div class="control-group<?php echo e($errors->has('courier')?' has-error':''); ?>">
                            
                            
                              <center><a href="#"><img src="<?php echo e(url('images/small',$data[0]["proof_of_payment"])); ?>" alt="" onclick="window.open(this.src)" border="3"></a></center>
                            
                        </div>
                         <div class="control-group">
                            <?php if($data[0]->status == 'unverified'): ?>
                                <center><input type="submit" name="submit" value="Verify Payment" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded"></center>
                            <?php elseif($data[0]->status == 'verified'): ?>
                                <center><input type="submit" name="submit" value="Deliver" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded"></center>
                            <?php else: ?>
                                <center><b>Verified</b></center>
                            <?php endif; ?>
                        </div>
                        <br>
                    </form>
                </div>
            </div>
            
        </div>
            
        </div>
        </div>
    
    <div class="container-fluid">
        <?php if(Session::has('message')): ?>
            <div class="alert alert-success text-center" role="alert">
                <strong>Well done!</strong> <?php echo e(Session::get('message')); ?>

            </div>
        <?php endif; ?>
        <div class="widget-box">
            <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
                <h5>Approvement Detail</h5>
            </div>
            <div class="widget-content nopadding">
                <table class="table table-bordered data-table">
                    <thead>
                    <tr>
                        <th>No</th>
                        <th>item</th>
                        <th>Name</th>
                        <th>price</th>
                        <th>Quantity</th>
                        <th>Discount</th>
                        <th>Total</th>
                        
                    </tr>
                    </thead>
                    <tbody>
                   <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                                $image_products=DB::table('products')->select('image_name')->join('product_images','product_images.product_id','=','products.id')->where('products.id',$data->product_id)->get()->first();
                                $image_data = DB::table('products')->where('products.id',$data->product_id)->get()->first();
                        ?>
                        
                            <tr >
                                <td><?php echo e($loop->iteration); ?></td>
                                <td class="cart_product">
                                    
                                        <a href=""><img src="<?php echo e(url('images',$image_products->image_name)); ?>" alt="" style="width: 100px;"></a>
                                    
                                </td>
                                <td class="cart_description">
                                    <p style="font-size: 15px"><?php echo e($image_data->product_name); ?></p>
                                </td>
                                <td class="cart_price">
                                    <p style="font-size: 15px">Rp <?php echo e(number_format($image_data->price)); ?></p>
                                </td>

                                <td class="cart_quantity">
                                    <?php echo e($data->qty); ?>

                                </td>
                                <td>
                                    <?php echo e($data->discount); ?>%
                                </td>

                                <td class="cart_total">
                                    <p style="font-size: 15px">Rp <?php echo e(number_format($data->qty*$data->selling_price)); ?></p>
                                </td>
                                
                            </tr>

                            
                             
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsblock'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="<?php echo e(asset('js/jquery.ui.custom.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.uniform.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/matrix.js')); ?>"></script>
    <script src="<?php echo e(asset('js/matrix.tables.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
    <script>
      $(document).on('click', '.deleteRecord', function (e) {
          e.preventDefault();
          var id = $(this).data('id');
          swal({
            title: "Are you sure!",
            type: "error",
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes!",
            showCancelButton: true,
           },
           function () {
              $.ajax({
                type: "POST",
                url: "admin/courier/"+id,
                data: {id:id},
                success: function (data) {
                              //
                    }         
            });
           });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\PRAKTIKUM PROGNET\test_auth\resources\views//admin/transaksi/approvement_detail.blade.php ENDPATH**/ ?>