<?php /* D:\KULIAH\PRAKTIKUM PROGNET\test_auth\resources\views/auth/register.blade.php */ ?>
<?php $__env->startSection('title','Account'); ?>
<?php $__env->startSection('page','Account'); ?>
<?php $__env->startSection('content'); ?>
<div class="aa-myaccount-area">         
    <div class="row">
      <div class="col-md-6">
        <div class="aa-myaccount-register">                 
         <h4>Register</h4>
         <form method="POST" action="<?php echo e(route('register')); ?>" class="aa-login-form">
          <?php echo csrf_field(); ?>
            <label for="name">Name<span>*</span></label>
            <input type="text" id="name" name="name" placeholder="Name">
            <label for="email">Email<span>*</span></label>
            <input type="text" id="email" name="email" placeholder="Email">
            <label for="">Password<span>*</span></label>
            <input type="password" id="password" name="password" placeholder="Password">
            <?php if($errors->has('password')): ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('password')); ?></strong>
            </span>
        <?php endif; ?>
            <label for="">Confirm Password<span>*</span></label>
            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
            <input type="text" name="status" value=NULL hidden="">
            <input type="text" name="profile_image" value=NULL hidden="">
            <button type="submit" class="aa-browse-btn">Register</button>                    
          </form>
        </div>
      </div>
    </div>          
 </div>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>