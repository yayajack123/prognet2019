<?php $__env->startSection('title','Your Cart'); ?>
<?php $__env->startSection('page',' Cart'); ?>
<?php $__env->startSection('content'); ?>
<div class="container"><legend>Transaction</legend></div>
<section id="cart-view">
  <div class="container">
        <div class="cart-view-area">
        <div class="cart-view-table">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <td>No</td>
                        <td >Address</td>
                        <td >Total</td>
                        <td >Courier</td>
                        <td >Timeout</td>
                        <td >Payment & Detail</td>
                        <td >Status</td>
                        
                    </tr>
                    </thead>
                    <tbody style="color: black;">
                            
                        <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($loop->iteration); ?>

                                </td>
                                <td >
                                    
                                    <p><?php echo e($transaction->address); ?></p>
                                    
                                </td>
                                <td>
                                    <p style="font-size: 15px">Rp <?php echo e(number_format($transaction->total)); ?></p>
                                </td>
                                <td>
                                    <p style="font-size: 15px"><?php echo e($transaction->courier); ?></p>
                                </td>
                                <td>
                                    <p><?php echo e($transaction->timeout); ?></p>
                                </td>

                                
                                <td>
                                    <a href="/transaction/<?php echo e($transaction->id); ?>"><button class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">Payment & Detail</button></a>
                                </td>

                                <td >
                                    <?php if(!empty($transaction->status)): ?>
                                        <p><?php echo e($transaction->status); ?></p>
                                    <?php else: ?>
                                        <p>insert Your Payment proof</p>
                                    <?php endif; ?>
                                </td>                 
                            </tr>    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\PRAKTIKUM PROGNET\test_auth\resources\views/user/transaction_list.blade.php ENDPATH**/ ?>