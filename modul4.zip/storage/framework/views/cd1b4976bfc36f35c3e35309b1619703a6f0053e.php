<?php $__env->startSection('title','Detail Produk'); ?>
<?php $__env->startSection('page','Detail Produk'); ?>
<?php $__env->startSection('content'); ?>

<!-- product category -->
<section id="aa-product-details">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="aa-product-details-area">
            <div class="aa-product-details-content">
              <div class="row">
                <!-- Modal view slider -->
                <div class="col-md-5 col-sm-5 col-xs-12">                              
                  <div class="aa-product-view-slider">                                
                    <div id="demo-1" class="simpleLens-gallery-container">
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="simpleLens-container">
                        <div class="simpleLens-big-image-container"><a data-lens-image="<?php echo e(asset('images/'.$images['image_name'])); ?>" class="simpleLens-lens-image"><img src="<?php echo e(asset('images/'.$images['image_name'])); ?>" class="simpleLens-big-image"></a></div>
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                    </div>
                  </div>
                </div>
                <!-- Modal view content -->
                <div class="col-md-7 col-sm-7 col-xs-12">
                  <div class="aa-product-view-content">
                  <h3><?php echo e($detail_product->product_name); ?></h3>
                    <div class="aa-price-block">
                      <span class="aa-product-view-price">IDR. <?php echo e(number_format($detail_product->price,2)); ?></span>
                      <p class="aa-product-avilability">Avilability: <span>In stock</span></p>
                    </div>
                  <p><?php echo e($detail_product->description); ?></p>
                    
                    <div class="aa-prod-quantity">
                        <?php if($detail_product->stock >0): ?>
                      <form action="<?php echo e(route('addToCart')); ?>" method="POST" role="form">
                          <?php echo csrf_field(); ?>
                          <input type="hidden" name="product_id" value="<?php echo e($detail_product->id); ?>">
                          <input type="hidden" name="product_name" value="<?php echo e($detail_product->product_name); ?>">
                          <input type="hidden" name="price" value="<?php echo e($detail_product->price); ?>" id="dynamicPriceInput">
                          <input type="hidden" name="stock" value="<?php echo e($detail_product->stock); ?>">
                  
                        <input class="form-control" type="number" name="quantity" >
                      <p class="aa-prod-category">
                          <?php $__currentLoopData = $kat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      Category: <a href="#"><?php echo e($kat->category_name); ?></a>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </p>
                    </div>
      
                    <div class="aa-prod-view-bottom">
                      
                        <button class="aa-add-to-cart-btn" > Add to cart</button>
                      </form>
                      <?php endif; ?>
                      <a class="aa-add-to-cart-btn" href="#">Wishlist</a>
                      <a class="aa-add-to-cart-btn" href="#">Compare</a>
                          
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="category-tab shop-details-tab"><!--category-tab-->
      <div class="col-sm-12">
          <ul class="nav nav-tabs">
              <li class="active"><a href="#reviews" data-toggle="tab">Reviews</a></li>
              
          </ul>
      </div>
      <div class="tab-content" id="reviews">
          <div class="tab-pane fade active in"  >
              <div class="container">
                  <div class="row">
                      <div class="col-sm-9">
                  <?php $__currentLoopData = $review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <p><b><?php echo e($review->name); ?></b></p>
                      <?php
                          $a = 5;
                      ?>
                      <?php for($i=0 ; $i< $review->rate; $i++): ?>
                          <?php
                              $a = $a-1;
                          ?>
                          <span style="color: gold;" class="fa fa-star checked"></span>
                      <?php endfor; ?>
                      <?php for($i=0 ; $i< $a; $i++): ?>
                          <span style="color: grey;" class="fa fa-star"></span>
                      <?php endfor; ?>
                      <input style="background-color: white;" type="text" readonly="" class="form-control" value="<?php echo e($review->content); ?>">
                      <hr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                  </div>
              </div>
          </div> 
          <div class="tab-pane fade" id="reviews" >
            <div class="col-sm-12">
                <ul>
                    <li><a href=""><i class="fa fa-user"></i>EUGEN</a></li>
                    <li><a href=""><i class="fa fa-clock-o"></i>12:41 PM</a></li>
                    <li><a href=""><i class="fa fa-calendar-o"></i>31 DEC 2014</a></li>
                </ul>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                <p><b>Write Your Review</b></p>

                <form action="#">
                                <span>
                                    <input type="text" placeholder="Your Name"/>
                                    <input type="email" placeholder="Email Address"/>
                                </span>
                    <textarea name="" ></textarea>
                    <b>Rating: </b> <img src="<?php echo e(asset('frontEnd/images/product-details/rating.png')); ?>" alt="" />
                    <button type="button" class="btn btn-default pull-right">
                        Submit
                    </button>
                </form>
            </div>
        </div> 
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\PRAKTIKUM PROGNET\test_auth\resources\views/user/produkdetail.blade.php ENDPATH**/ ?>